package com.company;

import java.net.InterfaceAddress;

public class Main {
    int sum;
    public static void main(String[] args) {

        // write your code here

        // Question 1 : Write an Interface with a
        // method to add 4 numbers and return the sum of it
        // Also create another method which will add all the number
        //given to sum up into an array.

        //Question 2 : Write a method which takes array and print the sum of
        // of it.
    }


}
